/**
 * Copyright 2015 Comcast Cable Communications Management, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
/**
 * @file service_alive.h
 *
 * @description This file is used to manage keep alive section
 *
 */
 
#ifndef _SERVICE_ALIVE_H_
#define _SERVICE_ALIVE_H_

#include <pthread.h>

/*----------------------------------------------------------------------------*/
/*                             Function Prototypes                            */
/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif
  
void *serviceAliveTask();
pthread_cond_t *get_global_svc_con(void);
pthread_mutex_t *get_global_svc_mut(void);

#ifdef __cplusplus
}
#endif
    

#endif

