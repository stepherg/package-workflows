/*
 * If not stated otherwise in this file or this component's Licenses.txt file the
 * following copyright and licenses apply:
 *
 * Copyright 2015 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

/**********************************************************************
   Copyright [2014] [Cisco Systems, Inc.]
 
   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at
 
       http://www.apache.org/licenses/LICENSE-2.0
 
   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
**********************************************************************/

/**********************************************************************

        For Dbus base library Implementation,
        Common Component Software Platform (CCSP)

    ---------------------------------------------------------------

    environment:

        platform dependent

    ---------------------------------------------------------------

    author:

        Qiang Tu

    ---------------------------------------------------------------

    revision:

        06/17/11    initial revision.

**********************************************************************/

#ifndef CCSP_MESSAGE_BUS_H
#define CCSP_MESSAGE_BUS_H

#ifdef CCSP_ENABLE_DBUS
#include <dbus/dbus.h>
/* Forward declare internal DBus type */
typedef struct DBusLoop DBusLoop;
#else
/* Stub types when DBus is disabled (default) */
#include <stdlib.h>
typedef void* DBusConnection;
typedef void* DBusMessage;
typedef void* DBusLoop;
typedef void* DBusWatch;
typedef void* DBusTimeout;
typedef void* DBusPendingCall;
typedef int (*DBusObjectPathMessageFunction)(void*, void*, void*);
typedef int DBusHandlerResult;
typedef int DBusDispatchStatus;
typedef int dbus_bool_t;

/* DBusObjectPathVTable structure */
typedef struct {
    void (*unregister_function)(DBusConnection*, void*);
    DBusObjectPathMessageFunction message_function;
    void (*dbus_internal_pad1)(void*);
    void (*dbus_internal_pad2)(void*);
    void (*dbus_internal_pad3)(void*);
    void (*dbus_internal_pad4)(void*);
} DBusObjectPathVTable;

/* Stub DBusError structure */
typedef struct {
    const char *name;
    const char *message;
    unsigned int dummy1 : 1;
    unsigned int dummy2 : 1;
    unsigned int dummy3 : 1;
    unsigned int padding1 : 29;
    void *padding2;
} DBusError;

/* DBus constants */
#define DBUS_TYPE_INVALID           0
#define DBUS_TYPE_STRING            ((int) 's')
#define DBUS_HANDLER_RESULT_HANDLED 0
#define DBUS_HANDLER_RESULT_NOT_YET_HANDLED 1
#define DBUS_MESSAGE_TYPE_SIGNAL    1
#define DBUS_MESSAGE_TYPE_METHOD_RETURN 2
#define DBUS_INTERFACE_LOCAL        "org.freedesktop.DBus.Local"
#define DBUS_DISPATCH_COMPLETE      0
#define DBUS_SERVICE_DBUS           "org.freedesktop.DBus"
#define DBUS_PATH_DBUS              "/org/freedesktop/DBus"
#define DBUS_INTERFACE_DBUS         "org.freedesktop.DBus"
#define DBUS_NAME_FLAG_ALLOW_REPLACEMENT 0x1
#define DBUS_NAME_FLAG_REPLACE_EXISTING  0x2
#define DBUS_NAME_FLAG_DO_NOT_QUEUE      0x4
#define DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER 1
#define DBUS_REQUEST_NAME_REPLY_ALREADY_OWNER 4

/* DBus stub function declarations */
void dbus_error_init(DBusError *error);
void dbus_error_free(DBusError *error);
int dbus_error_is_set(const DBusError *error);
DBusConnection* dbus_connection_open_private(const char *address, DBusError *error);
void dbus_connection_close(DBusConnection *connection);
void dbus_connection_unref(DBusConnection *connection);
DBusConnection* dbus_connection_ref(DBusConnection *connection);
void dbus_connection_lock(DBusConnection *connection);
void dbus_connection_unlock(DBusConnection *connection);
int dbus_bus_register(DBusConnection *connection, DBusError *error);
int dbus_bus_request_name(DBusConnection *connection, const char *name, unsigned int flags, DBusError *error);
int dbus_connection_send(DBusConnection *connection, DBusMessage *message, unsigned int *serial);
int dbus_connection_send_with_reply(DBusConnection *connection, DBusMessage *message, DBusPendingCall **pending, int timeout_ms);
DBusMessage* dbus_connection_send_with_reply_and_block(DBusConnection *connection, DBusMessage *message, int timeout_ms, DBusError *error);
int dbus_connection_get_is_connected(DBusConnection *connection);
int dbus_connection_set_dispatch_status_function(DBusConnection *connection, void *function, void *data, void *free_data);
int dbus_connection_set_watch_functions(DBusConnection *connection, void *add, void *remove, void *toggle, void *data, void *free_data);
int dbus_connection_set_timeout_functions(DBusConnection *connection, void *add, void *remove, void *toggle, void *data, void *free_data);
int dbus_connection_get_dispatch_status(DBusConnection *connection);
int dbus_connection_try_register_object_path(DBusConnection *connection, const char *path, const DBusObjectPathVTable *vtable, void *user_data, DBusError *error);
int dbus_connection_add_filter(DBusConnection *connection, void *function, void *user_data, void *free_data);
DBusMessage* dbus_message_new_method_call(const char *bus_name, const char *path, const char *iface, const char *method);
DBusMessage* dbus_message_new_signal(const char *path, const char *iface, const char *name);
void dbus_message_unref(DBusMessage *message);
DBusMessage* dbus_message_ref(DBusMessage *message);
int dbus_message_append_args(DBusMessage *message, int first_arg_type, ...);
int dbus_message_get_type(DBusMessage *message);
int dbus_message_is_signal(DBusMessage *message, const char *iface, const char *name);
const char* dbus_message_get_error_name(DBusMessage *message);
const char* dbus_message_get_destination(DBusMessage *message);
void dbus_free(void *memory);
void* dbus_loop_ref(DBusLoop *loop);
void dbus_loop_unref(DBusLoop *loop);
int dbus_loop_remove_wake(DBusLoop *loop);
int dbus_loop_add_watch(DBusLoop *loop, DBusWatch *watch);
int dbus_loop_remove_watch(DBusLoop *loop, DBusWatch *watch);
void dbus_loop_toggle_watch(DBusLoop *loop, DBusWatch *watch);
int dbus_loop_add_timeout(DBusLoop *loop, DBusTimeout *timeout);
int dbus_loop_remove_timeout(DBusLoop *loop, DBusTimeout *timeout);
int dbus_loop_queue_dispatch(DBusLoop *loop, DBusConnection *connection);
/* dbus_new0 macro for type-safe allocation */
#define dbus_new0(type, count) ((type*)calloc((count), sizeof(type)))
void dbus_pending_call_set_notify(DBusPendingCall *pending, void *function, void *user_data, void *free_data);
DBusMessage* dbus_pending_call_steal_reply(DBusPendingCall *pending);
void dbus_pending_call_cancel(DBusPendingCall *pending);
void dbus_pending_call_unref(DBusPendingCall *pending);
#endif

#include <pthread.h>
#include <rbus/rbus.h>
/*
notes: see readme.txt
*/

//match the error code in ccsp_base_api.h
#define CCSP_Message_Bus_OK             100
#define CCSP_Message_Bus_OOM            101
#define CCSP_Message_Bus_ERROR          102

#define CCSP_MESSAGE_BUS_CANNOT_CONNECT 190
#define CCSP_MESSAGE_BUS_TIMEOUT        191
#define CCSP_MESSAGE_BUS_NOT_EXIST      192
#define CCSP_MESSAGE_BUS_NOT_SUPPORT    193 //remote can't support this api

// resource limits
#define CCSP_MESSAGE_BUS_MAX_CONNECTION         15
#define CCSP_MESSAGE_BUS_MAX_FILTER             50
#define CCSP_MESSAGE_BUS_MAX_PATH               20

#define CCSP_MESSAGE_BUS_TIMEOUT_MAX_SECOND     60

#define WRITEID         "WRITEID"
#define PARAM_SIZE      "PARAM_SIZE"
#define SESSIONID       "SESSIONID"
#ifdef COMMIT
    #undef COMMIT
#endif
#define COMMIT          "COMMIT"
#define INVALID_PARAM   "INVALID_PARAM"
#define RESULT          "RESULT"
#define OBJNAME         "OBJNAME"
#define INST_NUM        "INST_NUM"
#define PRIORITY        "PRIORITY"
#define PARAM_NAME      "PARAM_NAME"
#define NEXT_LEVEL      "NEXT_LEVEL"


typedef void*(*CCSP_MESSAGE_BUS_MALLOC) ( size_t size ); // this signature is different from standard malloc
typedef void (*CCSP_MESSAGE_BUS_FREE)   ( void * ptr );

/*copy from ansc so we don't rely on ansc*/
typedef  struct
_CCSP_MSG_SINGLE_LINK_ENTRY
{
    struct  _CCSP_MSG_SINGLE_LINK_ENTRY*     Next;

} CCSP_MSG_SINGLE_LINK_ENTRY,  *PCCSP_MSG_SINGLE_LINK_ENTRY;

/*
 * special single linked list, the difference is that this one keeps track of the first element; we use this list as the
 * FIFO queue
 */
typedef  struct
_CCSP_MSG_QUEUE
{
    PCCSP_MSG_SINGLE_LINK_ENTRY               First;
    PCCSP_MSG_SINGLE_LINK_ENTRY               Last;

} CCSP_MSG_QUEUE,  *PCCSP_MSG_QUEUE;

typedef  struct
_CCSP_REQ_DESCRIPTOR
{
    CCSP_MSG_SINGLE_LINK_ENTRY               Linkage;
    DBusConnection  *conn;
    DBusMessage     *message;
    void            *user_data;

} CCSP_REQ_DESCRIPTOR,  *PCCSP_REQ_DESCRIPTOR;

#define  CCSP_MSG_ACCESS_CONTAINER(address, type, field)     \
         ((type*)((char*)(address) - (unsigned long)(&((type*)0)->field)))

typedef struct _CCSP_MESSAGE_PATH_INFO
{
    char *path;
//    DBusObjectPathMessageFunction callback;
    DBusObjectPathVTable echo_vtable;
    void *user_data;

} CCSP_MESSAGE_PATH_INFO;

typedef struct _CCSP_MESSAGE_FILTER
{
    char* path;
    char *interface;
    char *event;
    char *sender;
    int used;

} CCSP_MESSAGE_FILTER;

typedef struct _CCSP_MESSAGE_BUS_CONNECTION
{
    DBusConnection *conn;
    char address[256];
    pthread_mutex_t connect_mutex;
    int connected;
    void * bus_info_ptr;
    DBusLoop *loop;
    int self_pipe[2];
    pthread_mutex_t dispatch_mutex;
    int needs_dispatch;
    pthread_t loop_thread;
    pthread_t connect_thread;

} CCSP_MESSAGE_BUS_CONNECTION;

typedef struct _CCSP_MESSAGE_BUS_INFO
{
    char      component_id[256];
    DBusObjectPathMessageFunction   sig_callback;
    DBusObjectPathMessageFunction   default_sig_callback;
    void * user_data;
    int run;
    CCSP_MESSAGE_BUS_CONNECTION connection[CCSP_MESSAGE_BUS_MAX_CONNECTION];
    CCSP_MESSAGE_FILTER filters[CCSP_MESSAGE_BUS_MAX_FILTER];
    CCSP_MESSAGE_PATH_INFO path_array[CCSP_MESSAGE_BUS_MAX_PATH];
    pthread_mutex_t info_mutex;
    void * CcspBaseIf_func;
    CCSP_MESSAGE_BUS_MALLOC  mallocfunc ;
    CCSP_MESSAGE_BUS_FREE      freefunc ;
    
    pthread_mutex_t msg_mutex;
    pthread_cond_t  msg_threshold_cv;
    CCSP_MSG_QUEUE *msg_queue;
    DBusObjectPathMessageFunction thread_msg_func;
    int dbus_connect_thread_count;
    int dbus_loop_thread_count;
    void* rbus_callback;
    rbusHandle_t rbus_handle;

} CCSP_MESSAGE_BUS_INFO;

typedef struct _CCSP_DEADLOCK_DETECTION_INFO
{
    pthread_mutex_t info_mutex;
    char *          messageType;
    void *          parameterInfo;
    unsigned long   size;
    unsigned long   enterTime;
    unsigned long   detectionDuration;
    unsigned long   timepassed;

} CCSP_DEADLOCK_DETECTION_INFO;

#define deadlock_detection_log_linenum 200
#define deadlock_detection_log_linelen 192 
#define deadlock_detection_log_file    "/var/log/ccsp_emergency.log"

typedef char DEADLOCK_ARRAY[deadlock_detection_log_linenum][deadlock_detection_log_linelen];

typedef struct _CCSP_MESSAGE_BUS_CB_DATA
{
    pthread_mutex_t count_mutex;
    pthread_cond_t count_threshold_cv;
    char*         response;
    DBusMessage *message;
    int succeed;

} CCSP_MESSAGE_BUS_CB_DATA;

// void ccsp_msg_check_resp_sync (DBusPendingCall *pcall, void *user_data); // local, RTian 07/03/2013

// EXTERNAL INTERFACES

void CCSP_Msg_SleepInMilliSeconds(int milliSecond);

int  CCSP_Msg_IsRbus_enabled(void);

/*if mallocfunc, freefunc,config_file is NULL, default value will be used */
int CCSP_Message_Bus_Init
(
    char*             component_id,
    char * config_file,
    void **bus_handle,
    CCSP_MESSAGE_BUS_MALLOC mallocfunc,
    CCSP_MESSAGE_BUS_FREE   freefunc
);

void CCSP_Message_Bus_Exit
(
    void *bus_handle
);

/*can be called multi-time, sender, path,interface,event_name at least 1 is not null*/
int  CCSP_Message_Bus_Register_Event
(
    void* bus_handle,
    const char* sender,
    const char* path,
    const char* interface,
    const char* event_name
);

int  CCSP_Message_Bus_UnRegister_Event
(
    void* bus_handle,
    const char* sender,
    const char* path,
    const char* interface,
    const char* event_name
);

void  CCSP_Message_Bus_Set_Event_Callback
(
    void* bus_handle,
    DBusObjectPathMessageFunction   callback,
    void * user_data
);

/*can register more than one time*/
#define CCSP_Message_Bus_Register_Path CCSP_Message_Bus_Register_Path2

int CCSP_Message_Bus_Register_Path2
(
    void* bus_handle,
    const char* path,
    DBusObjectPathMessageFunction funcptr,
    void * user_data
);

/*send on a connection, privite function*/
int  CCSP_Message_Bus_Send_Str
(
    DBusConnection *conn,
    char* component_id,
    const char* path,
    const char* interface,
    const char* method,
    char* request
);

int CCSP_Message_Bus_Send_Msg
(
    void* bus_handle,
    DBusMessage *message,
    int timeout_seconds,
    DBusMessage **result
);

/*not recommended  for multithread high speed app, it will crash */
int CCSP_Message_Bus_Send_Msg_Block
(
    void* bus_handle,
    DBusMessage *message,
    int timeout_seconds,
    DBusMessage **result
);

#define DBUS_REGISTER_PATH_TIMES 10

#endif /* CCSP_MESSAGE_BUS_H */

